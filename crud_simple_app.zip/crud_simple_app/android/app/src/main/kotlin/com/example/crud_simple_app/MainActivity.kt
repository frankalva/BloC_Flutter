package com.example.crud_simple_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
