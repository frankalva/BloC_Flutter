part of 'product_bloc.dart';

sealed class ProductState extends Equatable {
  const ProductState();
  
  @override
  List<Object> get props => [];
}

//Estado inicial del producto
final class ProductInitial extends ProductState {}

final class ProductLoadingState extends ProductState{}

//clase que carga los productos en el estado
final class ProductLoadedState extends ProductState{
  const ProductLoadedState({required this.products});
  final List<Product> products;


  @override
  List<Object> get props => [products];
}

//clase que maneja si esta vacio pero en el estado
final class ProductIsEmpty extends ProductState{}

//Manejar un mensaje de error en el estado
final class ProductLoadingFailedState extends ProductState{
  const ProductLoadingFailedState({required this.error});
  final String error;
}
