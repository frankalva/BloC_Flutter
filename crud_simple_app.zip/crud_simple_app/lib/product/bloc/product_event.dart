part of 'product_bloc.dart';

sealed class ProductEvent extends Equatable {
  const ProductEvent();

  @override
  List<Object> get props => [];
}

//Inicializamos el evento que podria emitir diferentes estados
class GetProductEvent extends ProductEvent{}