import 'package:bloc/bloc.dart';
import 'package:crud_simple_app/product/data/model/product_model.dart';
import 'package:crud_simple_app/product/data/repository/product_repository.dart';
import 'package:equatable/equatable.dart';

part 'product_event.dart';
part 'product_state.dart';

class ProductBloc extends Bloc<ProductEvent, ProductState> {
  //Inicializamos la captura de la data
  final ProductRepository productRepository;  
  ProductBloc({required this.productRepository}) : super(ProductInitial()) {


    on<GetProductEvent>((event, emit) async{
      emit(ProductLoadingState());
      try{
        //almacenamos los productos en nuestra variable
        final products = await productRepository.getProducts();
        if(products.isEmpty){
          emit(ProductIsEmpty());
        }else{
          emit(ProductLoadedState(products: products));
        }
      }catch (e){
        final message = e.toString();
        emit(ProductLoadingFailedState(error: message));
      }
    });
  }
}
