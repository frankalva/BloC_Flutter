# crud_simple_app

A new Flutter project.
