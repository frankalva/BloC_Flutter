part of 'main_news_bloc.dart';

sealed class MainNewsEvent extends Equatable {
  const MainNewsEvent();

  @override
  List<Object> get props => [];
}

class MainNewsGetRecentNewsEvent extends MainNewsEvent{}