part of 'main_news_bloc.dart';

sealed class MainNewsState extends Equatable {
  const MainNewsState();
  
  @override
  List<Object> get props => [];
}

final class MainNewsInitial extends MainNewsState {}

final class MainNewsLoadingState extends MainNewsState{}

final class MainNewsGetNewsSuccessState extends MainNewsState{
  List<NewsEntity> news;
  MainNewsGetNewsSuccessState(this.news);

  @override
  List<Object> get props => [news];
}

final class MainNewsErrorState extends MainNewsState{
  final String message;
  const MainNewsErrorState(this.message);

  @override
  List<Object> get props => [message];
}
