class Constant {
  String apiBaseUrl = 'https://newsapi.org';
  String apiKey = 'fefe0c021fa244aa88ec1e64c0342cf7';
}