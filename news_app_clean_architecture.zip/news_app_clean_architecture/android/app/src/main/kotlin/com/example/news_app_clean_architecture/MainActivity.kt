package com.example.news_app_clean_architecture

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
