# news_app_clean_architecture

A new Flutter project.
