package com.example.text_change_bloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
