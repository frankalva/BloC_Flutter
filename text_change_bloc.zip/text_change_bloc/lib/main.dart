import 'package:flutter/material.dart';
import 'package:text_change_bloc/app.dart';

void main() {
  runApp(const MainApp());
}


