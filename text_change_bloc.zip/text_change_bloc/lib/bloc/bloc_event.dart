part of 'bloc_bloc.dart';

sealed class BlocEvent {
  const BlocEvent();
}

final class ChangeBlocText extends BlocEvent{
  const ChangeBlocText(); // evento para que cambie el texto
}

