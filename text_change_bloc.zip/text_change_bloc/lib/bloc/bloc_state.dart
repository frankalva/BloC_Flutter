part of 'bloc_bloc.dart';

sealed class BlocState extends Equatable {
  final int index; //pos
  final String text; //texto
  const BlocState({required this.index,  required this.text});
  
  @override
  List<Object> get props => [index,text];

  const BlocState.empty() : index = 0, text = 'Initial text';

}

final class BlocInitial extends BlocState{ //
  const BlocInitial(): super(index: 0, text: 'Initial text');
}


final class BlocUpdated extends BlocState{
  const BlocUpdated({required super.index,  required super.text});
}

