import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'bloc_event.dart';
part 'bloc_state.dart';

class BlocBloc extends Bloc<BlocEvent, BlocState> {

  final List textList = [
    "initial text",
    "secont text",
    "tirdth text"
  ];


  BlocBloc() : super(const BlocInitial()) {
    on<BlocEvent>((event, Emitter<BlocState> emit) {
      try{
        int newIndex = state.index+1;
        if (newIndex >= textList.length){
          newIndex = 0;
        }
        emit(BlocUpdated(index: newIndex, text: textList[newIndex]));

      }on Exception catch (e){
        print(e);
      }
    });
  }
}
