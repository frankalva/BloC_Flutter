import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:text_change_bloc/bloc/bloc_bloc.dart';

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: BlocProvider(
        create: (context) => BlocBloc(),
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Text Change'),
          ),
          body: BlocConsumer<BlocBloc, BlocState>(
            listener: (context, state) {
              
            },
            builder: (context, state) {
              return Text(
                state.text,
              );
            },
          ),
        ),
      ),
    );
  }
}

class TextChangeController extends StatelessWidget {
  const TextChangeController({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        
      ],
    );
  }
}
//https://www.bacancytechnology.com/blog/flutter-bloc-tutorial